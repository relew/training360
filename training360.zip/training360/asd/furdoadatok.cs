﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asd
{
    class Furdoadatok
    {
        public int Number { get; set; }
        public int Guest { get; set; }
        public byte Section { get; set; }
        public TimeSpan Time { get; set; }
        public byte Outin { get; set; }


        public Furdoadatok(int number, int guest, byte section, TimeSpan time, byte outin)
        {
            Number = number;
            Guest = guest;
            Section = section;
            Time = time;
            Outin = outin;

        }

        
    }
    public class szaunak
    {
        public int Sguest { get; set; }
        public TimeSpan Stime { get; set; }
        public int Snumber { get; set; }

        public szaunak(int sguest, TimeSpan stime, int snumber)
        {
            Sguest = sguest;
            Stime = stime;
            Snumber = snumber;

        }
    }

    public class szaunakki
    {
        public int Kguest { get; set; }
        public TimeSpan Ktime { get; set; }
        public int Knumber { get; set; }

        public szaunakki(int kguest, TimeSpan ktime, int knumber)
        {
            Kguest = kguest;
            Ktime = ktime;
            Knumber = knumber;

        }
    }


}
