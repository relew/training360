﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace asd
{
    public partial class Form1 : Form
    {

        private string filepath;
        private List<Furdoadatok> furdoadatoks;
        private List<szaunak> szaunaks;
        private List<szaunakki> szaunakkis;

        public Form1()
        {
            InitializeComponent();
            filepath = "furdoadat.txt";
            furdoadatoks = new List<Furdoadatok>();
            szaunaks = new List<szaunak>();
            szaunakkis = new List<szaunakki>();
        }
                    

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Enabled = false;
            using (var ssr = new StreamReader(filepath))
            {
                
                byte hour, minute, sec;
                
                while (!ssr.EndOfStream)
                {
                    int a = 0;

                    for (int i = 0; i < 640; i++)
                    {
                        string line = ssr.ReadLine();
                        string[] data = line.Split(' ');
                        int number = a;
                        int guest = int.Parse(data[0]);
                        byte section = byte.Parse(data[1]);
                        byte outin = byte.Parse(data[2]);
                        hour = byte.Parse(data[3]);
                        minute = byte.Parse(data[4]);
                        sec = byte.Parse(data[5]);
                        TimeSpan time = new TimeSpan(hour, minute, sec);

                        Furdoadatok s = new Furdoadatok(number, guest, section, time, outin);
                        furdoadatoks.Add(s);
                        a++;
                    }

                }

                ssr.Close();

                // feladat 1
                label8.Text = "A txt file beolvasásra került.";
            }

            //feladat 2
            var query = (from Furdoadatok in furdoadatoks
                        where Furdoadatok.Section == 0 && Furdoadatok.Outin == 1
                        orderby Furdoadatok.Time ascending
                        select Furdoadatok).FirstOrDefault();


            label9.Text = String.Format("Az első vendég {0} -kor lépett ki az öltözőből.",query.Time);

           var query2 =  from Furdoadatok in furdoadatoks
                          where Furdoadatok.Section == 0 && Furdoadatok.Outin == 1
                          orderby Furdoadatok.Time descending
                          select Furdoadatok;

            var maxDate = new TimeSpan();
            foreach (var Furdoadatok in query2)
            {
                if(Furdoadatok.Time > maxDate)
                {
                    maxDate = Furdoadatok.Time;
                }
            }
            label10.Text = String.Format("Az utolsó vendég {0} -kor lépett ki az öltözőből.", maxDate);

            //feladat 3
            var egy = from Furdoadatok in furdoadatoks
                      where Furdoadatok.Number >= 0
                      orderby Furdoadatok.Time descending
                      select Furdoadatok;

            var egy3 = from Furdoadatok in furdoadatoks
                      where Furdoadatok.Number >= 0
                      orderby Furdoadatok.Time descending
                      select Furdoadatok;

            int egyben = 0;
            foreach (var a in egy)
            {
                int db = 0;
                foreach (var b in egy3)
                {
                    if (a.Guest == b.Guest)
                    {
                        db++;
                    }
                }

                if(db == 4){
                 egyben++; }
                db++;
            }
            label11.Text = String.Format("A fürdőben {0} vendég járt csak egy részlegen.", egyben/4);
            
            //4 feladat
            TimeSpan maxido = new TimeSpan(0,0,0);
            int maxember = 0;
            int maxhuman = 0;

            foreach (var a in egy)
            {
                var be = (from Furdoadatok in furdoadatoks
                          where Furdoadatok.Guest == a.Guest
                          orderby Furdoadatok.Time ascending
                          select Furdoadatok).FirstOrDefault();

                var ki = (from Furdoadatok in furdoadatoks
                          where Furdoadatok.Guest == a.Guest
                          orderby Furdoadatok.Time descending
                          select Furdoadatok).FirstOrDefault();

                if (maxido < ki.Time - be.Time)
                {
                    maxido = ki.Time - be.Time;
                    maxember = ki.Number;
                }
            }

            foreach(var b in egy)
            {
                if(b.Number == maxember)
                {
                    maxhuman = b.Guest;
                }
            }
            label12.Text = String.Format("A legtöbb időt eltöltő vendég {0}. és {1} időt töltött el.", maxhuman, maxido);

            //5 feladat
            int reggel = 0;
            int del = 0;
            int este = 0;

            foreach (var a in egy)
            {
                if(a.Section == 0 && a.Outin ==1)
                {
                    if(new TimeSpan(9,0,0)> a.Time)
                    { reggel++;
                    }
                    if (new TimeSpan(9, 0, 0) < a.Time && a.Time < new TimeSpan(16, 0, 0))
                    {
                        del++;
                    }
                    if (new TimeSpan(16, 0, 0) < a.Time)
                    {
                        este++;
                    }


                }
            }
            label13.Text = String.Format("6-9 óra között {0} vendég érkezett a fürdőbe.", reggel);

            label19.Text = String.Format("9-16 óra között {0} vendég érkezett a fürdőbe.", del);

            label20.Text = String.Format("16 után  {0} vendég érkezett a fürdőbe.",este);

            // 6 feladat
            FileStream kiir = new FileStream("szauna.txt", FileMode.Create);
            StreamWriter ir = new StreamWriter(kiir);

            var saunabe = from Furdoadatok in furdoadatoks
                           where Furdoadatok.Section == 2 && Furdoadatok.Outin == 0
                           select Furdoadatok;

            var saunaki = from Furdoadatok in furdoadatoks
                          where Furdoadatok.Section == 2 && Furdoadatok.Outin == 1
                          select Furdoadatok;

            int n = 0;
            foreach (var a in saunabe)
            {
                TimeSpan saunaido = new TimeSpan(0, 0, 0);
                foreach (var b in saunaki)
                {
                    
                    if (a.Guest == b.Guest && a.Number == ((b.Number) - 1) && b.Time > a.Time)
                    {
                        saunaido += b.Time - a.Time;

                    }
                    if (saunaido > new TimeSpan(0, 0, 0))
                    {
                        int sguest = a.Guest;
                        TimeSpan stime = saunaido;
                        int snumber = n;
                        szaunak sa = new szaunak(sguest, stime,snumber);
                        szaunaks.Add(sa);
                        //ir.WriteLine("{0} {1} {2}", snumber, sguest, stime);
                        n++;
                        
                        
                    }

                }

            }

            var saunairas = from szaunak in szaunaks
                            where szaunak.Sguest >= 0
                            select szaunak;

            int c = 0;
            TimeSpan szaun = new TimeSpan(0, 0, 0);

            foreach (var a in saunairas)
            {
                foreach (var b in saunairas)
                {
                    if (b.Snumber == 101)
                    {
                        int kguest = a.Sguest;
                        TimeSpan ktime = a.Stime;
                        int knumber = c;
                        szaunakki sk = new szaunakki(kguest, ktime, knumber);
                        szaunakkis.Add(sk);
                        c++;

                    }
                    if(a.Snumber == ((b.Snumber) - 1) && !(a.Stime == b.Stime))
                    {
                        if(a.Sguest==b.Sguest)
                        {
                            szaun = a.Stime + b.Stime;
                        }
                        else
                        {
                            szaun = a.Stime;
                        }
                        
                        int kguest = a.Sguest;
                        TimeSpan ktime = szaun;
                        int knumber = c;
                        szaunakki sk = new szaunakki(kguest, ktime, knumber);
                        szaunakkis.Add(sk);
                       // ir.WriteLine("{0} {1}", kguest  , ktime);
                        c++;
                    }

                }

            }

            var kis = (from szaunakki in szaunakkis
                      where szaunakki.Kguest == 101
                      orderby szaunakki.Ktime descending
                      select szaunakki).FirstOrDefault();

            label18.Text = String.Format("szauna.txt kimentésre került.");

            var results = from p in szaunakkis
                          group p.Ktime by p.Kguest into g
                          select new { Kguest = g.Key, Ktime = g.Max()};

           foreach(var a in results)
            {
                TimeSpan asd = new TimeSpan(0, 0, 0);
                asd = a.Ktime;
                ir.WriteLine("{0} {1}", a.Kguest, a.Ktime);
            }

            ir.Close();
            kiir.Close();

            // 7 feladat
            //uszoda szam
            var uszoda = from Furdoadatok in furdoadatoks
                         where Furdoadatok.Section == 1 && Furdoadatok.Outin == 0
                         select Furdoadatok;
            
            int uszodadupla = 0;
            foreach(var a in uszoda)
            {
                foreach (var b in uszoda)
                {
                    if (b.Guest == a.Guest)
                    {
                        uszodadupla++;
                    }
                }
            }

            var z= uszoda.Count()-((uszodadupla- uszoda.Count())/2);
            label14.Text = String.Format("Uszoda: {0}", z);

            //szauna szam
            var szauna = from Furdoadatok in furdoadatoks
                         where Furdoadatok.Section == 2 && Furdoadatok.Outin == 0
                         select Furdoadatok;

            int szaunadupla = 0;
            foreach (var a in szauna)
            {
                foreach (var b in szauna)
                {
                    if (b.Guest == a.Guest)
                    {
                        szaunadupla++;
                    }
                }
            }

            var y = szauna.Count() - ((szaunadupla - szauna.Count()) / 2);
            label15.Text = String.Format("Szauna: {0}", y);
            
            //gyogyviz szam
            var gyogy = from Furdoadatok in furdoadatoks
                         where Furdoadatok.Section == 3 && Furdoadatok.Outin == 0
                         select Furdoadatok;

            int gyogydupla = 0;
            foreach (var a in gyogy)
            {
                foreach (var b in gyogy)
                {
                    if (b.Guest == a.Guest)
                    {
                        gyogydupla++;
                    }
                }
            }

            var gy = gyogy.Count() - ((gyogydupla - gyogy.Count()) / 2);
            label16.Text = String.Format("Gyógyvizes medence: {0}", gy);

            //strand szam
            var strand = from Furdoadatok in furdoadatoks
                         where Furdoadatok.Section == 4 && Furdoadatok.Outin == 0
                         select Furdoadatok;

            int stranddupla = 0;
            foreach (var a in strand)
            {
                foreach (var b in strand)
                {
                    if (b.Guest == a.Guest)
                    {
                        stranddupla++;
                    }
                }
            }

            var st = strand.Count() - ((stranddupla - strand.Count()) / 2);
            label17.Text = String.Format("Strand: {0}", st);
             }

        }
    }
    








    

    

